<?php
	$attrPrice = 0;
	$sessionCur = session()->get('currency');
	$sessionCurr = DB::table('currencies')->where('id',$sessionCur)->first();
	$databaseCurr = DB::table('currencies')->where('is_default',1)->first();
	$curr = $sessionCurr ? $sessionCurr: $databaseCurr;

	if($prod->user_id != 0){
        $attrPrice = $prod->price + $gs->fixed_commission + ($prod->price/100) * $gs->percentage_commission ;
        }

    if(!empty($prod->size) && !empty($prod->size_price)){
          $attrPrice += $prod->size_price[0];
      }

      if(!empty($prod->attributes)){
        $attrArr = json_decode($prod->attributes, true);
      }
?>

<?php if(!empty($prod->attributes)): ?>
	<?php
	$attrArr = json_decode($prod->attributes, true);
	?>
	<?php endif; ?>

	<?php if(!empty($attrArr)): ?>
		<?php $__currentLoopData = $attrArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attrKey => $attrVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(array_key_exists("details_status",$attrVal) && $attrVal['details_status'] == 1): ?>
				<?php $__currentLoopData = $attrVal['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($loop->first): ?>
					<?php if(!empty($attrVal['prices'][$optionKey])): ?>
						<?php
							$attrPrice = $attrPrice + $attrVal['prices'][$optionKey] * $curr->value;
						?>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php
  $withSelectedAtrributePrice = $attrPrice+$prod->price;
  $withSelectedAtrributePrice = round(($withSelectedAtrributePrice) * $curr->value,2);


?>
	

		<li>
			<div class="single-box">
				<div class="left-area">
					<img src="<?php echo e($prod->thumbnail ? asset('assets/images/thumbnails/'.$prod->thumbnail):asset('assets/images/noimage.png')); ?>" alt="">
				</div>
				<div class="right-area">
						<div class="stars">
							<div class="ratings">
								<div class="empty-stars"></div>
								<div class="full-stars" style="width:<?php echo e(App\Models\Rating::ratings($prod->id)); ?>%"></div>
							</div>
							</div>
							<h4 class="price"><?php echo e($attrPrice != 0 ?  $gs->currency_format == 0 ? $curr->sign.$withSelectedAtrributePrice : $withSelectedAtrributePrice.$curr->sign :$prod->showPrice()); ?> <del><?php echo e($prod->showPreviousPrice()); ?></del> </h4>
							<p class="text"><a href="<?php echo e(route('front.product',$prod->slug)); ?>"><?php echo e(mb_strlen($prod->name,'utf-8') > 35 ? mb_substr($prod->name,0,35,'utf-8').'...' : $prod->name); ?></a></p>
				</div>
			</div>
		</li>




<?php /**PATH C:\wamp\htdocs\geniuscart-v2.1\project\resources\views/includes/product/list-product.blade.php ENDPATH**/ ?>