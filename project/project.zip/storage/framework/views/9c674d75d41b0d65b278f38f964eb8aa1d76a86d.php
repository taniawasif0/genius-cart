<?php
  $attrPrice = 0;
  $sessionCurr = session()->get('currency');
  $databaseCurr = DB::table('currencies')->where('is_default',1)->first();
  $curr = $sessionCurr ? $sessionCurr:$databaseCurr;
?>

<?php if(!empty($prod->attributes)): ?>
<?php
  $attrArr = json_decode($prod->attributes, true);
?>
<?php endif; ?>

<?php if(!empty($attrArr)): ?>
  <?php $__currentLoopData = $attrArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attrKey => $attrVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(array_key_exists("details_status",$attrVal) && $attrVal['details_status'] == 1): ?>
      <?php $__currentLoopData = $attrVal['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->first): ?>
          <?php if(!empty($attrVal['prices'][$optionKey])): ?>
            <?php
                $attrPrice = $attrPrice + $attrVal['prices'][$optionKey] * $curr->value;
            ?>
          <?php endif; ?>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php
  $withSelectedAtrributePrice = $attrPrice+$prod->price;
?><?php /**PATH C:\wamp\htdocs\geniuscart-v2.1\project\resources\views/includes/product/with-attribute-price.blade.php ENDPATH**/ ?>