      <div class="alert alert-success validation" style="display: none;">
      <button type="button" class="close alert-close"><span>×</span></button>
            <p class="text-left"></p> 
      </div>
      <div class="alert alert-danger validation" style="display: none;">
      <button type="button" class="close alert-close"><span>×</span></button>
            <ul class="text-left">
            </ul>
      </div><?php /**PATH C:\wamp\htdocs\geniuscart-v2.1\project\resources\views/includes/admin/form-both.blade.php ENDPATH**/ ?>